"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import BlankWorkspace from "~/components/editor/BlankWorkspace";
import { useIsUserLoggedIn } from "~/hooks/api/auth/index";
import { useGetProject, useUpdateProject } from "~/hooks/api/project/index";

export default function ProjectWorkspacePage() {
  const router = useRouter();
  const params = useParams<{ id: string }>();
  const id = params.id;
  const { isUserLoggedIn, isLoading: isAuthLoading } = useIsUserLoggedIn();
  const { project, isLoading: isProjectLoading } = useGetProject(id);
  const { updateProjectAsync } = useUpdateProject();
  const [title, setTitle] = useState("Untitled");

  useEffect(() => {
    if (!isAuthLoading && !isUserLoggedIn) {
      router.replace("/googlelogin");
    }
  }, [isAuthLoading, isUserLoggedIn, router]);

  useEffect(() => {
    if (project?.title) {
      setTitle(project.title);
    }
  }, [project?.title]);

  useEffect(() => {
    if (!id || !project) {
      return;
    }

    const timeout = window.setTimeout(() => {
      updateProjectAsync({
        id,
        title: title.trim() || "Untitled",
        description: project.description || "",
      });
    }, 700);

    return () => window.clearTimeout(timeout);
  }, [id, project, title, updateProjectAsync]);

  const handleBack = () => {
    router.push("/dashboard");
  };

  const handleTitleChange = (nextTitle: string) => {
    setTitle(nextTitle);
  };

  if (isAuthLoading || !isUserLoggedIn || isProjectLoading) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-[#0F0D0A] text-[#D6C4A3]">
        <div className="text-center">
          <div className="mx-auto h-8 w-8 animate-spin rounded-full border border-[#A9854F]/20 border-t-[#A9854F]" />
          <p className="mt-4 font-mono text-[10px] uppercase tracking-[0.2em] text-[#655A4E]">Opening file</p>
        </div>
      </main>
    );
  }

  return <BlankWorkspace title={title} onTitleChange={handleTitleChange} onBack={handleBack} />;
}
