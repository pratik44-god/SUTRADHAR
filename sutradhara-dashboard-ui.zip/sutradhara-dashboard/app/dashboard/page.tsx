"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import DashboardHeader from "~/components/dashboard/DashboardHeader";
import EmptyProjects from "~/components/dashboard/EmptyProjects";
import ProjectGrid from "~/components/dashboard/ProjectGrid";
import ProjectStats from "~/components/dashboard/ProjectStats";
import { useIsUserLoggedIn, useLogout, useUser } from "~/hooks/api/auth/index";
import { useCreateProject, useDeleteProject, useProjects } from "~/hooks/api/project/index";

export default function DashboardPage() {
  const router = useRouter();
  const { isUserLoggedIn, isLoading: isAuthLoading } = useIsUserLoggedIn();
  const { user } = useUser();
  const { logout } = useLogout();
  const { projects, isLoading: isProjectsLoading } = useProjects();
  const { createProjectAsync, status: createStatus } = useCreateProject();
  const { deleteProjectAsync, status: deleteStatus } = useDeleteProject();

  useEffect(() => {
    if (!isAuthLoading && !isUserLoggedIn) {
      router.replace("/googlelogin");
    }
  }, [isAuthLoading, isUserLoggedIn, router]);

  const handleLogout = () => {
    logout(undefined, {
      onSuccess: () => {
        router.replace("/googlelogin");
      },
    });
  };

  const handleCreateBlank = async () => {
    const project = await createProjectAsync({
      title: "Untitled",
      description: "",
    });

    if (project?.id) {
      router.push(`/dashboard/project/${project.id}`);
    }
  };

  const handleOpenProject = (id: string) => {
    router.push(`/dashboard/project/${id}`);
  };

  const handleDeleteProject = async (id: string) => {
    const shouldDelete = window.confirm("Delete this project?");

    if (!shouldDelete) {
      return;
    }

    await deleteProjectAsync({ id });
  };

  if (isAuthLoading || !isUserLoggedIn) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-[#0F0D0A] text-[#D6C4A3]">
        <div className="text-center">
          <div className="mx-auto h-8 w-8 animate-spin rounded-full border border-[#A9854F]/20 border-t-[#A9854F]" />
          <p className="mt-4 font-mono text-[10px] uppercase tracking-[0.2em] text-[#655A4E]">Opening workspace</p>
        </div>
      </main>
    );
  }

  const projectList = Array.isArray(projects) ? projects : [];
  const isBusy = createStatus === "pending" || deleteStatus === "pending";
  const firstName = user?.fullName?.trim()?.split(/\s+/)[0] || "Creator";

  return (
    <main className="min-h-screen bg-[#0F0D0A] text-[#F0E6D2]">
      <DashboardHeader fullName={user?.fullName} onLogout={handleLogout} />

      <div className="mx-auto grid min-h-[calc(100vh-76px)] max-w-[1500px] grid-cols-[210px_minmax(0,1fr)]">
        <aside className="hidden border-r border-[#A9854F]/10 px-4 py-6 md:block">
          <nav className="space-y-1">
            <button type="button" className="flex w-full items-center gap-3 rounded-xl border border-[#A9854F]/20 bg-[#211A13] px-3 py-2.5 text-left text-sm text-[#F0E6D2]">
              <span className="text-[#A9854F]">⌂</span> Home
            </button>
            <button type="button" className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-sm text-[#857767] transition hover:bg-[#17130F] hover:text-[#D6C4A3]">
              <span>□</span> Projects <span className="ml-auto rounded-md bg-[#211A13] px-1.5 py-0.5 font-mono text-[9px]">{projectList.length}</span>
            </button>
            <button type="button" className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-sm text-[#857767] transition hover:bg-[#17130F] hover:text-[#D6C4A3]">
              <span>♧</span> Shared with me
            </button>
            <button type="button" className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-sm text-[#857767] transition hover:bg-[#17130F] hover:text-[#D6C4A3]">
              <span>▱</span> Archive
            </button>
          </nav>

          <div className="my-7 h-px bg-[#A9854F]/10" />

          <button type="button" className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-sm text-[#857767] transition hover:bg-[#17130F] hover:text-[#D6C4A3]">
            <span>♧</span> Team
          </button>

          <div className="mt-[calc(100vh-430px)] space-y-1">
            <button type="button" className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-sm text-[#857767]">⚙ Settings</button>
            <button type="button" className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-sm text-[#857767]">? Help & Support</button>
          </div>
        </aside>

        <section className="min-w-0 px-5 py-8 lg:px-9">
          <div className="mx-auto max-w-[1050px]">
            <div className="flex items-end justify-between gap-4">
              <div>
                <div className="font-mono text-[9px] uppercase tracking-[0.25em] text-[#A9854F]">Welcome back</div>
                <h1 className="mt-2 font-serif text-[34px] leading-tight text-[#F0E6D2]">Good to see you, {firstName}.</h1>
                <p className="mt-2 text-sm text-[#766B5D]">Turn your ideas into structured visual projects.</p>
              </div>
              <ProjectStats totalProjects={projectList.length} />
            </div>

            <div className="mt-8 grid grid-cols-2 gap-3 xl:grid-cols-4">
              <button type="button" onClick={handleCreateBlank} disabled={isBusy} className="group rounded-2xl border border-[#A9854F]/20 bg-[#17130F] p-4 text-left transition hover:-translate-y-0.5 hover:border-[#A9854F]/45 hover:bg-[#1C1712] disabled:cursor-wait disabled:opacity-60">
                <span className="text-2xl text-[#A9854F]">□</span>
                <div className="mt-5 text-sm text-[#E4D8C5]">Blank File</div>
                <div className="mt-1 text-xs text-[#6F6559]">Start from scratch <span className="float-right text-[#A9854F]">→</span></div>
              </button>
              <button type="button" className="rounded-2xl border border-[#A9854F]/20 bg-[#17130F] p-4 text-left transition hover:-translate-y-0.5 hover:border-[#A9854F]/45 hover:bg-[#1C1712]">
                <span className="text-2xl text-[#A9854F]">✦</span>
                <div className="mt-5 text-sm text-[#E4D8C5]">Generate with AI</div>
                <div className="mt-1 text-xs text-[#6F6559]">Turn ideas into diagrams <span className="float-right text-[#A9854F]">→</span></div>
              </button>
              <button type="button" className="rounded-2xl border border-[#A9854F]/20 bg-[#17130F] p-4 text-left transition hover:-translate-y-0.5 hover:border-[#A9854F]/45 hover:bg-[#1C1712]">
                <span className="text-2xl text-[#A9854F]">▦</span>
                <div className="mt-5 text-sm text-[#E4D8C5]">Use Template</div>
                <div className="mt-1 text-xs text-[#6F6559]">Get started quickly <span className="float-right text-[#A9854F]">→</span></div>
              </button>
              <button type="button" className="rounded-2xl border border-[#A9854F]/20 bg-[#17130F] p-4 text-left transition hover:-translate-y-0.5 hover:border-[#A9854F]/45 hover:bg-[#1C1712]">
                <span className="text-2xl text-[#A9854F]">♧</span>
                <div className="mt-5 text-sm text-[#E4D8C5]">For Team</div>
                <div className="mt-1 text-xs text-[#6F6559]">Collaborate together <span className="float-right text-[#A9854F]">→</span></div>
              </button>
            </div>

            <div className="mt-10 flex items-end justify-between">
              <div>
                <h2 className="font-serif text-[25px] text-[#E9DDC9]">Recent Projects</h2>
                <p className="mt-1 text-xs text-[#655B50]">Continue where you left off.</p>
              </div>
              {projectList.length > 0 && <span className="font-mono text-[9px] uppercase tracking-[0.16em] text-[#8A765C]">{projectList.length} total</span>}
            </div>

            <div className="mt-4">
              {isProjectsLoading ? (
                <div className="space-y-2">
                  {[1, 2, 3].map((item) => <div key={item} className="h-[86px] animate-pulse rounded-2xl border border-[#A9854F]/10 bg-[#14110E]" />)}
                </div>
              ) : projectList.length === 0 ? (
                <EmptyProjects onCreateBlank={handleCreateBlank} />
              ) : (
                <ProjectGrid projects={projectList} onOpen={handleOpenProject} onDelete={handleDeleteProject} />
              )}
            </div>

            <div className="mt-8 rounded-2xl border border-[#A9854F]/10 bg-[#14110E]/50 px-4 py-3 text-xs text-[#62594E]">
              Team activity will appear here once project activity and member hooks are connected. No fake activity is shown in the UI.
            </div>
          </div>
        </section>
      </div>
    </main>
  );
}
