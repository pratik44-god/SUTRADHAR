# Sutradhara Dashboard UI

Frontend-only dashboard/editor structure using the existing auth and project hooks.

Files:
- app/dashboard/page.tsx
- app/dashboard/project/[id]/page.tsx
- components/dashboard/DashboardHeader.tsx
- components/dashboard/EmptyProjects.tsx
- components/dashboard/ProjectCard.tsx
- components/dashboard/ProjectGrid.tsx
- components/dashboard/ProjectStats.tsx
- components/editor/BlankWorkspace.tsx

Assumed existing imports:
- ~/hooks/api/project/index
- ~/hooks/api/auth/index
- ~/components/branding/logo
