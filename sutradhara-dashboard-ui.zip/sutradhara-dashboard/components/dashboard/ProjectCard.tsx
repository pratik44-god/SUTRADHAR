"use client";

interface ProjectCardProps {
  project: {
    id: string;
    title?: string | null;
    description?: string | null;
    createdAt?: Date | string | null;
    updatedAt?: Date | string | null;
  };
  onOpen: (id: string) => void;
  onDelete: (id: string) => void;
}

const formatDate = (value?: Date | string | null) => {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "—";
  return date.toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
};

const formatEdited = (value?: Date | string | null) => {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "—";

  const diff = Date.now() - date.getTime();
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);

  if (minutes < 1) return "just now";
  if (minutes < 60) return `${minutes}m ago`;
  if (hours < 24) return `${hours}h ago`;
  if (days < 7) return `${days}d ago`;
  return formatDate(value);
};

export default function ProjectCard({ project, onOpen, onDelete }: ProjectCardProps) {
  const title = project.title?.trim() || "Untitled";
  const description = project.description?.trim() || "No description yet";

  const handleOpen = () => {
    onOpen(project.id);
  };

  const handleDelete = () => {
    onDelete(project.id);
  };

  return (
    <article className="group flex min-h-[86px] items-center gap-4 rounded-2xl border border-[#A9854F]/15 bg-[#14110E]/75 px-4 py-3 transition duration-200 hover:border-[#A9854F]/35 hover:bg-[#19140F]">
      <button
        type="button"
        onClick={handleOpen}
        className="flex min-w-0 flex-1 items-center gap-4 text-left"
      >
        <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border border-[#A9854F]/20 bg-[#211A13]">
          <svg width="23" height="23" viewBox="0 0 24 24" fill="none" aria-hidden="true">
            <rect x="4" y="5" width="16" height="14" rx="2" stroke="#A9854F" strokeWidth="1.3" />
            <circle cx="9" cy="10" r="1.2" fill="#D6C4A3" />
            <circle cx="15" cy="14" r="1.2" fill="#D6C4A3" />
            <path d="M10 10H14M10 14H13" stroke="#9A6847" strokeWidth="1.2" strokeLinecap="round" />
          </svg>
        </div>

        <div className="min-w-0 flex-1">
          <h3 className="truncate text-sm font-medium text-[#EDE2CF] group-hover:text-[#F0E6D2]">{title}</h3>
          <p className="mt-1 max-w-[460px] truncate text-xs text-[#766B5D]">{description}</p>
        </div>
      </button>

      <div className="hidden w-[105px] shrink-0 md:block">
        <div className="font-mono text-[8px] uppercase tracking-[0.16em] text-[#5F554A]">Created</div>
        <div className="mt-1 text-xs text-[#A99A87]">{formatDate(project.createdAt)}</div>
      </div>

      <div className="hidden w-[105px] shrink-0 lg:block">
        <div className="font-mono text-[8px] uppercase tracking-[0.16em] text-[#5F554A]">Edited</div>
        <div className="mt-1 text-xs text-[#A99A87]">{formatEdited(project.updatedAt)}</div>
      </div>

      <button
        type="button"
        onClick={handleDelete}
        className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-[#766B5D] opacity-0 transition hover:bg-[#211A13] hover:text-[#D6C4A3] group-hover:opacity-100"
        aria-label={`Delete ${title}`}
      >
        ⋯
      </button>
    </article>
  );
}
