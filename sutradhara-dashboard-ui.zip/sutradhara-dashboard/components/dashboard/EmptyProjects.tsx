"use client";

interface EmptyProjectsProps {
  onCreateBlank: () => void;
}

export default function EmptyProjects({ onCreateBlank }: EmptyProjectsProps) {
  const handleCreateBlank = () => {
    onCreateBlank();
  };

  return (
    <section className="rounded-3xl border border-[#A9854F]/15 bg-[#14110E]/70 px-6 py-14 text-center">
      <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl border border-[#A9854F]/25 bg-[#211A13]">
        <svg width="30" height="30" viewBox="0 0 32 32" fill="none" aria-hidden="true">
          <path d="M8 7.5H18L24 13.5V24.5H8V7.5Z" stroke="#A9854F" strokeWidth="1.4" />
          <path d="M18 7.5V13.5H24M12 18H20M12 21H18" stroke="#D6C4A3" strokeWidth="1.2" strokeLinecap="round" />
        </svg>
      </div>
      <h2 className="mt-5 font-serif text-2xl text-[#F0E6D2]">Your workspace is empty</h2>
      <p className="mx-auto mt-2 max-w-md text-sm leading-6 text-[#766B5D]">Start with a blank file and turn the first thought into a structure.</p>
      <button
        type="button"
        onClick={handleCreateBlank}
        className="mt-6 rounded-xl border border-[#A9854F]/45 bg-[#211A13] px-5 py-3 text-sm text-[#E7D6BB] transition hover:border-[#A9854F] hover:bg-[#2A2118]"
      >
        Create blank file
      </button>
    </section>
  );
}
