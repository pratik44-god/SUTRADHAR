"use client";

interface ProjectStatsProps {
  totalProjects: number;
}

export default function ProjectStats({ totalProjects }: ProjectStatsProps) {
  return (
    <div className="flex items-center gap-5 font-mono text-[10px] uppercase tracking-[0.16em] text-[#766B5D]">
      <span><b className="font-medium text-[#D6C4A3]">{totalProjects}</b> {totalProjects === 1 ? "project" : "projects"}</span>
      <span className="h-3 w-px bg-[#A9854F]/20" />
      <span>Idea · Structure · Collaboration</span>
    </div>
  );
}
