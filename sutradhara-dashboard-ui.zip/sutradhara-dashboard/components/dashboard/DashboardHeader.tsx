"use client";

import LogoMark from "~/components/branding/logo";

interface DashboardHeaderProps {
  fullName?: string | null;
  onLogout: () => void;
}

export default function DashboardHeader({ fullName, onLogout }: DashboardHeaderProps) {
  const name = fullName?.trim() || "Creator";
  const initials = name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join("") || "C";

  const handleLogout = () => {
    onLogout();
  };

  return (
    <header className="flex h-[76px] shrink-0 items-center border-b border-[#A9854F]/15 bg-[#0F0D0A]/95 px-6 backdrop-blur-xl">
      <div className="flex min-w-[225px] items-center gap-3">
        <LogoMark size={42} />
        <div>
          <div className="font-serif text-[19px] tracking-[0.02em] text-[#F0E6D2]">Sutradhara</div>
          <div className="font-mono text-[8px] uppercase tracking-[0.28em] text-[#A9854F]">Idea workspace</div>
        </div>
      </div>

      <div className="mx-auto flex w-full max-w-[520px] items-center">
        <div className="flex h-10 w-full items-center gap-3 rounded-xl border border-[#A9854F]/20 bg-[#17130F] px-3 text-[#8F806D]">
          <svg width="17" height="17" viewBox="0 0 24 24" fill="none" aria-hidden="true">
            <circle cx="11" cy="11" r="6.5" stroke="currentColor" strokeWidth="1.5" />
            <path d="M16 16L21 21" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
          </svg>
          <span className="text-sm">Search projects, files, or anything...</span>
          <span className="ml-auto rounded-md border border-[#A9854F]/15 px-2 py-1 font-mono text-[10px] text-[#766B5D]">⌘ K</span>
        </div>
      </div>

      <div className="ml-6 flex min-w-[225px] items-center justify-end gap-3">
        <button
          type="button"
          onClick={handleLogout}
          className="hidden text-xs text-[#8F806D] transition hover:text-[#F0E6D2] sm:block"
        >
          Sign out
        </button>
        <div className="flex h-9 w-9 items-center justify-center rounded-full border border-[#A9854F]/50 bg-[#211A13] font-mono text-xs text-[#F0E6D2]">
          {initials}
        </div>
        <div className="hidden text-left md:block">
          <div className="max-w-[105px] truncate text-xs text-[#E5D9C6]">{name}</div>
          <div className="font-mono text-[9px] uppercase tracking-[0.16em] text-[#756A5B]">Creator</div>
        </div>
        <span className="text-[#A9854F]">⌄</span>
      </div>
    </header>
  );
}
