"use client";

import ProjectCard from "./ProjectCard";

interface ProjectGridProps {
  projects: Array<{
    id: string;
    title?: string | null;
    description?: string | null;
    createdAt?: Date | string | null;
    updatedAt?: Date | string | null;
  }>;
  onOpen: (id: string) => void;
  onDelete: (id: string) => void;
}

export default function ProjectGrid({ projects, onOpen, onDelete }: ProjectGridProps) {
  return (
    <div className="space-y-2">
      {projects.map((project) => (
        <ProjectCard key={project.id} project={project} onOpen={onOpen} onDelete={onDelete} />
      ))}
    </div>
  );
}
