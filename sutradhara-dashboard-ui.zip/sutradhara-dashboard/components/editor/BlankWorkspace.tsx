"use client";

interface BlankWorkspaceProps {
  title: string;
  onTitleChange: (title: string) => void;
  onBack: () => void;
}

export default function BlankWorkspace({ title, onTitleChange, onBack }: BlankWorkspaceProps) {
  const handleBack = () => {
    onBack();
  };

  const handleTitleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    onTitleChange(event.target.value);
  };

  return (
    <main className="flex h-[calc(100vh-64px)] min-h-0 flex-col bg-[#0F0D0A] text-[#F0E6D2]">
      <div className="flex h-14 shrink-0 items-center border-b border-[#A9854F]/15 bg-[#14110E] px-4">
        <button type="button" onClick={handleBack} className="mr-4 text-[#8E806E] hover:text-[#F0E6D2]">←</button>
        <input
          value={title}
          onChange={handleTitleChange}
          className="w-[230px] border-0 bg-transparent text-sm font-medium outline-none placeholder:text-[#5F554A]"
          placeholder="Untitled"
        />
        <span className="ml-2 font-mono text-[9px] uppercase tracking-[0.16em] text-[#655A4E]">Saved</span>

        <div className="ml-auto flex items-center gap-2">
          <button type="button" className="rounded-lg border border-[#A9854F]/15 px-3 py-2 text-xs text-[#8E806E] hover:border-[#A9854F]/35 hover:text-[#D6C4A3]">Undo</button>
          <button type="button" className="rounded-lg border border-[#A9854F]/15 px-3 py-2 text-xs text-[#8E806E] hover:border-[#A9854F]/35 hover:text-[#D6C4A3]">Redo</button>
          <div className="ml-2 h-7 w-7 rounded-full border border-[#A9854F]/40 bg-[#211A13]" />
          <button type="button" className="rounded-lg bg-[#A9854F] px-4 py-2 text-xs font-medium text-[#0F0D0A]">Share</button>
        </div>
      </div>

      <div className="relative flex min-h-0 flex-1 overflow-hidden">
        <aside className="flex w-14 shrink-0 flex-col items-center gap-3 border-r border-[#A9854F]/10 bg-[#12100D] py-4">
          {[
            "⌁",
            "▢",
            "T",
            "↗",
            "○",
          ].map((icon, index) => (
            <button
              key={`${icon}-${index}`}
              type="button"
              className={`flex h-9 w-9 items-center justify-center rounded-lg text-sm ${index === 0 ? "bg-[#211A13] text-[#D6C4A3]" : "text-[#655A4E] hover:bg-[#1B1712] hover:text-[#B39A72]"}`}
            >
              {icon}
            </button>
          ))}
        </aside>

        <section className="relative min-w-0 flex-1 overflow-hidden bg-[#0D0C0A]">
          <div className="absolute inset-0 opacity-40 [background-image:linear-gradient(rgba(169,133,79,0.06)_1px,transparent_1px),linear-gradient(90deg,rgba(169,133,79,0.06)_1px,transparent_1px)] [background-size:32px_32px]" />
          <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-center">
            <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full border border-[#A9854F]/35 bg-[#17130F] shadow-[0_0_80px_rgba(169,133,79,0.07)]">
              <div className="h-3 w-3 rotate-45 rounded-sm border border-[#D6C4A3] bg-[#211A13]" />
            </div>
            <h1 className="mt-5 font-serif text-2xl text-[#D6C4A3]">Start your structure</h1>
            <p className="mt-2 text-sm text-[#62594E]">Click anywhere and begin shaping your idea.</p>
          </div>

          <div className="absolute bottom-5 left-5 flex items-center gap-2 rounded-xl border border-[#A9854F]/15 bg-[#14110E]/90 px-3 py-2 text-[10px] text-[#6F6559] backdrop-blur">
            <span className="text-[#A9854F]">Space</span> pan · <span className="text-[#A9854F]">⌘ Z</span> undo · <span className="text-[#A9854F]">V</span> select
          </div>
        </section>

        <aside className="hidden w-[245px] shrink-0 border-l border-[#A9854F]/10 bg-[#12100D] xl:block">
          <div className="border-b border-[#A9854F]/10 px-4 py-4">
            <div className="font-mono text-[9px] uppercase tracking-[0.2em] text-[#756A5B]">Structure</div>
            <div className="mt-2 text-sm text-[#B39A72]">No elements yet</div>
          </div>
          <div className="px-4 py-4">
            <div className="font-mono text-[9px] uppercase tracking-[0.2em] text-[#756A5B]">Project</div>
            <div className="mt-3 space-y-3 text-xs text-[#766B5D]">
              <div className="flex justify-between"><span>Canvas</span><span className="text-[#A99A87]">Blank</span></div>
              <div className="flex justify-between"><span>Members</span><span className="text-[#A99A87]">1</span></div>
            </div>
          </div>
        </aside>
      </div>
    </main>
  );
}
